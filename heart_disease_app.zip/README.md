
# 🫀 Heart Disease Predictor

An interactive machine learning web app that predicts the likelihood of heart disease using logistic regression. Built with Streamlit.

## 📦 Files Included

- `app.py`: Streamlit app interface
- `heart_model.joblib`: Trained logistic regression model
- `heart.csv`: Dataset used for training (optional)
- `requirements.txt`: Package dependencies

## 🚀 How to Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## ✅ Features

- Logistic Regression model with 82% accuracy
- Clean UI with dark mode and heart illustration
- Patient input form with real-time predictions

